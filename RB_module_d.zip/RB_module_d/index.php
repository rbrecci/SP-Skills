<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API de Clima e Eventos</title>
    <link rel="stylesheet" href="./assets/style.css">
</head>
<body>
    <header>
        <h1>API de Clima e Eventos</h1><a href="./index.php">Voltar</a>
    </header>
    <main>
        <h2>Bem Vindo a API de Clima e Eventos!</h2>
    </main>
    <footer>
        <nav>
            <ul>
                <li><a href="./estacionamentos.php">Estacionamentos</a></li>
                <li><a href="./eventos.php">Eventos</a></li>
                <li><a href="./clima.php">Clima</a></li>
                <li><a href="./ambiente.php">Ambiente</a></li>
            </ul>
        </nav>
    </footer>
</body>
</html>