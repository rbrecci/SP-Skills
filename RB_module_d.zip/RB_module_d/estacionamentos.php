<?php

if($_GET){
    $latitude = $_GET['latitude'] ?? '';
    $longitude = $_GET['longitude'] ?? '';
} else {
    $latitude = 50;
    $longitude = 50;
}

$estacionamentos = [
    'Brotteaux' => ['availableSpaces' => mt_rand(0, 50), 'latitude'=> 45.764043, 'longitude' => 4.835659, 'location' => '12 Rue de Brotteaux, 69006 Lyon, France'],
    'Cordeliers' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.764501, 'longitude' => 4.835659, 'location' => 'Place des Cordeliers, 69002 Lyon, France'],
    'Gare de Lyon' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.755409, 'longitude' => 4.821223, 'location' => 'Place Charles de Gaulle, 69003 Lyon, France'],
    'Perrache' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.757501, 'longitude' => 4.842299, 'location' => 'Place Louis Pradel, 69002 Lyon, France'],
    'Croix-Rousse' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.772501, 'longitude' => 4.833239, 'location' => 'Place de la Croix-Rousse, 69004 Lyon, France'],
    'Vaise' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.786551, 'longitude' => 4.801299, 'location' => 'Place de Vaise, 69009 Lyon, France'],
    'Part-Dieu' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.758501, 'longitude' => 4.852299, 'location' => '151 Rue Servient, 69003 Lyon, France'],
    'Saint-Exupery' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.731501, 'longitude' => 4.886299, 'location' => 'Place de lAviation, 69003 Lyon, France'],
    'Lyon-Saint-Exupery' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.731501, 'longitude' => 4.886269, 'location' => 'Place de lAviation, 69003 Lyon, France'],
    'Ecully' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.783551, 'longitude' => 4.761259, 'location' => 'Rue de la Paix, 69130 Ecully, France'],
    'Bron' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.741501, 'longitude' => 4.912299, 'location' => 'Place de la Gare, 69500 Bron, France'],
    'Villeurbanne' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.766501, 'longitude' => 4.887299, 'location' => 'Place Lazare Goujon, 69100 Villeurbanne, France'],
    'Rillieux-la-Pape' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.814501, 'longitude' => 4.887293, 'location' => 'Place de la paix, 69140 Rillieux-la-Pape, France'],
    'Dardilly' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.806501, 'longitude' => 4.744293, 'location' => 'Place de la libert , 69570 Dardilly, France'],
    'Oullins' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.692501, 'longitude' => 4.814299, 'location' => 'Place de la Gare, 69600 Oullins, France'],
    'Sainte-Foy-les-Lyon' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.736501, 'longitude' => 4.801229, 'location' => 'Place de la Gare, 69110 Sainte-Foy-les-Lyon, France'],
    'Tassin-la-Demi-Lune' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.783501, 'longitude' => 4.744299, 'location' => 'Place de la Gare, 69160 Tassin-la-Demi-Lune, France'],
    'Vernaison' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.651504, 'longitude' => 4.809243, 'location' => 'Place de la Gare, 69390 Vernaison, France'],
    'Sathonay-Camp' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.857501, 'longitude' => 4.862233, 'location' => 'Place de la Gare, 69580 Sathonay-Camp, France'],
    'Cailloux-sur-Fontaines' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.883501, 'longitude' => 4.942299, 'location' => 'Place de la Gare, 69270 Cailloux-sur-Fontaines, France'],
    'Simandres' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.737501, 'longitude' => 4.886299, 'location' => 'Place de la Gare, 69590 Simandres, France'],
    'Solaize' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.666501, 'longitude' => 4.833299, 'location' => 'Place de la Gare, 69340 Solaize, France'],
    'Marennes' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.733506, 'longitude' => 4.833299, 'location' => 'Place de la Gare, 69270 Marennes, France'],
    'Loire-sur-Rhône' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.566501, 'longitude' => 4.805299, 'location' => 'Place de la Gare, 69700 Loire-sur-Rhône, France'],
    'Givors' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.583501, 'longitude' => 4.777299, 'location' => 'Place de la Gare, 69700 Givors, France'],
    'Grigny' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.603511, 'longitude' => 4.733255, 'location' => 'Place de la Gare, 69530 Grigny, France'],
    'Vaugneray' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.743501, 'longitude' => 4.633299, 'location' => 'Place de la Gare, 69670 Vaugneray, France'],
    'Chaponost' => ['availableSpaces' => mt_rand(0, 50), 'latitude' => 45.713531, 'longitude' => 4.744299, 'location' => 'Place de la Gare, 69630 Chaponost, France'],
];

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estacionamento</title>
    <link rel="stylesheet" href="./assets/style.css">
</head>
<body>
    <header>
        <h1>Estacionamento</h1><a href="./index.php">Voltar</a>
    </header>
    <main class="mainCards">
        <section class="cards">
            <div id="close"><strong>Fechar</strong></div>
            <div id="fix"><strong>Fixar</strong></div>
            <?php foreach($estacionamentos as $estacionamento => $dados): ?>
                <div class="card" id="<?= trim($estacionamento) ?>">
                    <p><?= $estacionamento ?></p>
                    <p><?= $dados['availableSpaces'] ?></p>
                    <p id="latitude<?= trim($estacionamento) ?>"><?= $dados['latitude'] ?></p>
                    <p id="longitude<?= trim($estacionamento) ?>"><?= $dados['longitude'] ?></p>
                    <p id="distance<?= trim($estacionamento) ?>"></p>
                </div>
                <?php endforeach; ?>
        </section>
        <input type="number" id="latitude" hidden value="<?= $latitude ?? '' ?>">
        <input type="number" id="longitude" hidden value="<?= $longitude ?? '' ?>">
        <div id="teste"></div>
    </main>
    <footer>
        <nav>
            <ul>
                <li><a href="./estacionamentos.php"><strong>Estacionamentos</strong></a></li>
                <li><a href="./eventos.php">Eventos</a></li>
                <li><a href="./clima.php">Clima</a></li>
                <li><a href="./ambiente.php">Ambiente</a></li>
            </ul>
        </nav>
    </footer>
    <script>
        const cards = document.querySelectorAll(".card"); 
        const close = document.getElementById("close");
        const fix = document.getElementById("fix");
        close.onclick = () => {
            document.querySelector(".focusCard").classList.remove("focusCard");
        }
        fix.onclick = () => {
            document.querySelector(".focusCard").classList.add("fixed");
        }
        cards.forEach(card => {
            card.onclick = () => {
                let cardName = card.id;
                card.classList.add("focusCard");
                let latitudeCard = Number(document.getElementById(`latitude${cardName}`).value); 
                let longitudeCard = Number(document.getElementById(`longitude${cardName}`).value);
                let distance = document.getElementById(`distance${cardName}`);
                let latitudeActual = Number(document.getElementById("latitude").value);
                let longitudeActual = Number(document.getElementById("longitude").value);

                distance.innerHTML = getDistanceFromLatLonInKm(latitudeCard, longitudeCard, latitudeActual, longitudeCard);
            }
            
        });

        const teste = document.getElementById("teste");
        function getDistanceFromLatLonInKm(latitude1, longitude1, latitude2, longitude2) {
            var R = 6371; // Radius of the earth in km
            var dLat = deg2rad(latitude2-latitude1);  // deg2rad below
            var dLon = deg2rad(longitude2-longitude1);
            var a =
            Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(deg2rad(latitude1)) * Math.cos(deg2rad(latitude2)) *
            Math.sin(dLon/2) * Math.sin(dLon/2)
            ;
            var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
            var d = R * c; // Distance in km
            return d;
        }


        function deg2rad(deg) {
            return deg * (Math.PI/180)
        }
    </script>
</body>
</html>