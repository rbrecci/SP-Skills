<?php



?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ambiente</title>
    <link rel="stylesheet" href="./assets/styleblack.css">
</head>
<body>
    <header>
        <h1>Ambiente</h1><a href="./indexDark.php">Voltar</a>
    </header>
    <main>
        <ul>
            <li><a href="./ambiente.php">Trocar Tema</a></li>
            <li><a href="#">Ordenar por Alfabeto</a></li>
            <li><a href="#">Ordenar por Distancia</a></li>
        </ul>
    </main>
    <footer>
        <nav>
            <ul>
                <li><a href="./estacionamentosDark.php">Estacionamentos</a></li>
                <li><a href="./eventosDark.php">Eventos</a></li>
                <li><a href="./climaDark.php">Clima</a></li>
                <li><a href="./ambienteDark.php"><strong>Ambiente</strong></a></li>
            </ul>
        </nav>
    </footer>
</body>
</html>