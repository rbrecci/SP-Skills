<?php



?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ambiente</title>
    <link rel="stylesheet" href="./assets/style.css">
</head>
<body>
    <header>
        <h1>Ambiente</h1><a href="./index.php">Voltar</a>
    </header>
    <main>
        <ul>
            <li><a href="./ambienteDark.php">Trocar Tema</a></li>
            <li><a href="#">Ordenar por Alfabeto</a></li>
            <li><a href="#">Ordenar por Distancia</a></li>
        </ul>
    </main>
    <footer>
        <nav>
            <ul>
                <li><a href="./estacionamentos.php">Estacionamentos</a></li>
                <li><a href="./eventos.php">Eventos</a></li>
                <li><a href="./clima.php">Clima</a></li>
                <li><a href="./ambiente.php"><strong>Ambiente</strong></a></li>
            </ul>
        </nav>
    </footer>
</body>
</html>