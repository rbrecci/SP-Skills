<?php


$data = [];
$date = new DateTime('2026-05-27');
for ($i = 0; $i < 7; $i++) {
    $data[] = [
        'location' => 'Lyon',
        'date' => $date->format('Y-m-d'),
        'status' => ['cloudy', 'rainy', 'sunny'][rand(0, 2)],
        'lower_temperature' => rand(10, 19),
        'upper_temperature' => rand(20, 28)
    ];
    $date->add(new DateInterval('P1D'));
};


?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clima</title>
    <link rel="stylesheet" href="./assets/style.css">
</head>
<body>
    <header>
        <h1>Clima</h1><a href="./index.php">Voltar</a>
    </header>
    <main class="climaMain">
        <?php foreach($data as $chave => $valor): ?>
            <div class="climacard">
                <p><?= $valor['date'] ?></p>
                <img src="./svn icons/<?= $valor['status'] ?>.svg" alt="Clima Imagem">
                <p><?= $valor['lower_temperature'] - $valor['upper_temperature'] ?>°C</p>
                <p class="clima"><?= $valor['status'] ?></p>
            </div>
        <?php endforeach; ?>
    </main>
    <footer>
        <nav>
            <ul>
                <li><a href="./estacionamentos.php">Estacionamentos</a></li>
                <li><a href="./eventos.php">Eventos</a></li>
                <li><a href="./clima.php"><strong>Clima</strong></a></li>
                <li><a href="./ambiente.php">Ambiente</a></li>
            </ul>
        </nav>
    </footer>
    <script>
        const clima = document.querySelectorAll('.clima');
        clima.forEach(status => {
            switch(status.innerHTML){
                case 'cloudy':
                    status.innerHTML = "Cloudy";
                break;
                case 'rainy':
                    status.innerHTML = "Rainy";
                break;
                case 'sunny':
                    status.innerHTML = "Sunny";
                break;
            }
        });
    </script>
</body>
</html>