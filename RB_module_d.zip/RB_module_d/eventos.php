<?php

$eventos = [
        ['title' => 'Riffs & Rhythms: Lyon Jazz Festival', 'image' => '/module_d_api.php/image.png?title=Riffs %26 Rhythms: Lyon Jazz Festival', 'date' => '2024-09-17'],
        ['title' => 'Harvest Hoedown: Lyon Autumn Market', 'image' => '/module_d_api.php/image.png?title=Harvest Hoedown: Lyon Autumn Market', 'date' => '2024-09-22'],
        ['title' => 'Monster Mash Bash: Lyon Halloween Party', 'image' => '/module_d_api.php/image.png?title=Monster Mash Bash: Lyon Halloween Party', 'date' => '2024-10-31'],
        ['title' => 'Joyeux Noël: Lyon Christmas Market', 'image' => '/module_d_api.php/image.png?title=Joyeux Noël: Lyon Christmas Market', 'date' => '2024-12-01'],
        ['title' => 'Countdown to Midnight: Lyon New Years Eve Party', 'image' => '/module_d_api.php/image.png?title=Countdown to Midnight: Lyon New Years Eve Party', 'date' => '2024-12-31'],
        ['title' => 'Winter Wonderland: Lyon Winter Festival', 'image' => '/module_d_api.php/image.png?title=Winter Wonderland: Lyon Winter Festival', 'date' => '2025-02-01'],
        ['title' => 'Spring Fling: Lyon Spring Carnival', 'image' => '/module_d_api.php/image.png?title=Spring Fling: Lyon Spring Carnival', 'date' => '2025-03-21'],
        ['title' => 'Easter Eggstravaganza: Lyon Easter Egg Hunt', 'image' => '/module_d_api.php/image.png?title=Easter Eggstravaganza: Lyon Easter Egg Hunt', 'date' => '2025-04-12'],
        ['title' => 'Summer Sounds: Lyon Summer Music Festival', 'image' => '/module_d_api.php/image.png?title=Summer Sounds: Lyon Summer Music Festival', 'date' => '2025-06-21'],
        ['title' => 'Vintage Vibes: Lyon Autumn Wine Festival', 'image' => '/module_d_api.php/image.png?title=Vintage Vibes: Lyon Autumn Wine Festival', 'date' => '2025-09-20'],
        ['title' => 'Jazz & Wine: Lyon Jazz & Wine Festival', 'image' => '/module_d_api.php/image.png?title=Jazz %26 Wine: Lyon Jazz %26 Wine Festival', 'date' => '2025-10-17'],
        ['title' => 'Holiday Cheer: Lyon Christmas Market', 'image' => '/module_d_api.php/image.png?title=Holiday Cheer: Lyon Christmas Market', 'date' => '2025-12-01'],
        ['title' => 'New Years Bash: Lyon New Years Eve Party', 'image' => '/module_d_api.php/image.png?title=New Years Bash: Lyon New Years Eve Party', 'date' => '2025-12-31'],
        ['title' => 'Winter Whimsy: Lyon Winter Festival', 'image' => '/module_d_api.php/image.png?title=Winter Whimsy: Lyon Winter Festival', 'date' => '2026-02-01'],
        ['title' => 'Spring Spectacle: Lyon Spring Carnival', 'image' => '/module_d_api.php/image.png?title=Spring Spectacle: Lyon Spring Carnival', 'date' => '2026-03-21'],
        ['title' => 'Easter Egg Hunt: Lyon Easter Egg Hunt', 'image' => '/module_d_api.php/image.png?title=Easter Egg Hunt: Lyon Easter Egg Hunt', 'date' => '2026-04-12'],
        ['title' => 'Summer Sounds: Lyon Summer Music Festival', 'image' => '/module_d_api.php/image.png?title=Summer Sounds: Lyon Summer Music Festival', 'date' => '2026-06-21'],
        ['title' => 'Vintage Vibes: Lyon Autumn Wine Festival', 'image' => '/module_d_api.php/image.png?title=Vintage Vibes: Lyon Autumn Wine Festival', 'date' => '2026-09-20'],
        ['title' => 'Summer Lovin: Lyon Summer Music Festival', 'image' => '/module_d_api.php/image.png?title=Summer Lovin: Lyon Summer Music Festival', 'date' => '2026-07-01'],
        ['title' => 'La Fête de la Musique: Lyon Music Festival', 'image' => '/module_d_api.php/image.png?title=La Fête de la Musique: Lyon Music Festival', 'date' => '2026-07-21'],
        ['title' => 'Bastille Day: Lyon French National Day', 'image' => '/module_d_api.php/image.png?title=Bastille Day: Lyon French National Day', 'date' => '2026-07-14'],
        ['title' => 'Les Nuits de Fourvière: Lyon Outdoor Concerts', 'image' => '/module_d_api.php/image.png?title=Les Nuits de Fourvière: Lyon Outdoor Concerts', 'date' => '2026-07-15'],
        ['title' => 'Autumn Colors: Lyon Fall Festival', 'image' => '/module_d_api.php/image.png?title=Autumn Colors: Lyon Fall Festival', 'date' => '2026-10-01'],
        ['title' => 'Halloween Party: Lyon Spooky Night', 'image' => '/module_d_api.php/image.png?title=Halloween Party: Lyon Spooky Night', 'date' => '2026-10-31'],
        ['title' => 'Christmas Market: Lyon Holiday Shopping', 'image' => '/module_d_api.php/image.png?title=Christmas Market: Lyon Holiday Shopping', 'date' => '2026-12-01'],
        ['title' => 'New Years Eve Party: Lyon Countdown', 'image' => '/module_d_api.php/image.png?title=New Years Eve Party: Lyon Countdown', 'date' => '2026-12-31'],
        ['title' => 'Winter Festival: Lyon Ice Skating', 'image' => '/module_d_api.php/image.png?title=Winter Festival: Lyon Ice Skating', 'date' => '2027-01-01'],
        ['title' => 'Carnival of Lights: Lyon Mardi Gras', 'image' => '/module_d_api.php/image.png?title=Carnival of Lights: Lyon Mardi Gras', 'date' => '2027-02-21'],
        ['title' => 'Easter Egg Hunt: Lyon Springtime Fun', 'image' => '/module_d_api.php/image.png?title=Easter Egg Hunt: Lyon Springtime Fun', 'date' => '2027-04-12'],
        ['title' => 'Summer Music Festival: Lyon Outdoor Concerts', 'image' => '/module_d_api.php/image.png?title=Summer Music Festival: Lyon Outdoor Concerts', 'date' => '2027-06-21'],
        ['title' => 'Vintage Car Show: Lyon Classic Cars', 'image' => '/module_d_api.php/image.png?title=Vintage Car Show: Lyon Classic Cars', 'date' => '2027-07-01'],
        ['title' => 'Bastille Day Parade: Lyon French National Day', 'image' => '/module_d_api.php/image.png?title=Bastille Day Parade: Lyon French National Day', 'date' => '2027-07-14'],
        ['title' => 'Les Nuits de Fourvière: Lyon Outdoor Theater', 'image' => '/module_d_api.php/image.png?title=Les Nuits de Fourvière: Lyon Outdoor Theater', 'date' => '2027-07-15'],
        ['title' => 'Autumn Wine Festival: Lyon Harvest Season', 'image' => '/module_d_api.php/image.png?title=Autumn Wine Festival: Lyon Harvest Season', 'date' => '2027-09-20'],
        ['title' => 'Halloween Costume Party: Lyon Spooky Night', 'image' => '/module_d_api.php/image.png?title=Halloween Costume Party: Lyon Spooky Night', 'date' => '2027-10-31'],
        ['title' => 'Christmas Tree Lighting: Lyon Holiday Cheer', 'image' => '/module_d_api.php/image.png?title=Christmas Tree Lighting: Lyon Holiday Cheer', 'date' => '2027-12-01'],
        ['title' => 'New Years Bash: Lyon Countdown', 'image' => '/module_d_api.php/image.png?title=New Years Bash: Lyon Countdown', 'date' => '2027-12-31'],
        ['title' => 'Winter Wonderland: Lyon Ice Skating', 'image' => '/module_d_api.php/image.png?title=Winter Wonderland: Lyon Ice Skating', 'date' => '2028-01-01'],
        ['title' => 'Carnival of Lights: Lyon Mardi Gras', 'image' => '/module_d_api.php/image.png?title=Carnival of Lights: Lyon Mardi Gras', 'date' => '2028-02-21'],
        ['title' => 'Easter Egg Hunt: Lyon Springtime Fun', 'image' => '/module_d_api.php/image.png?title=Easter Egg Hunt: Lyon Springtime Fun', 'date' => '2028-04-12'],
        ['title' => 'Summer Music Festival: Lyon Outdoor Concerts', 'image' => '/module_d_api.php/image.png?title=Summer Music Festival: Lyon Outdoor Concerts', 'date' => '2028-06-21'],
        ['title' => 'Vintage Car Show: Lyon Classic Cars', 'image' => '/module_d_api.php/image.png?title=Vintage Car Show: Lyon Classic Cars', 'date' => '2028-07-01'],
        ['title' => 'Bastille Day Parade: Lyon French National Day', 'image' => '/module_d_api.php/image.png?title=Bastille Day Parade: Lyon French National Day', 'date' => '2028-07-14'],
        ['title' => 'Les Nuits de Fourvière: Lyon Outdoor Theater', 'image' => '/module_d_api.php/image.png?title=Les Nuits de Fourvière: Lyon Outdoor Theater', 'date' => '2028-07-15'],
        ['title' => 'Autumn Wine Festival: Lyon Harvest Season', 'image' => '/module_d_api.php/image.png?title=Autumn Wine Festival: Lyon Harvest Season', 'date' => '2028-09-20'],
        ['title' => 'Halloween Party: Lyon Spooky Night', 'image' => '/module_d_api.php/image.png?title=Halloween Party: Lyon Spooky Night', 'date' => '2028-10-31'],
        ['title' => 'Christmas Market: Lyon Holiday Shopping', 'image' => '/module_d_api.php/image.png?title=Christmas Market: Lyon Holiday Shopping', 'date' => '2028-12-01'],
        ['title' => 'New Years Eve Party: Lyon Countdown', 'image' => '/module_d_api.php/image.png?title=New Years Eve Party: Lyon Countdown', 'date' => '2028-12-31'],
        ['title' => 'Winter Festival: Lyon Ice Skating', 'image' => '/module_d_api.php/image.png?title=Winter Festival: Lyon Ice Skating', 'date' => '2029-01-01'],
        ['title' => 'Carnival of Lights: Lyon Mardi Gras', 'image' => '/module_d_api.php/image.png?title=Carnival of Lights: Lyon Mardi Gras', 'date' => '2029-02-21'],
        ['title' => 'Easter Egg Hunt: Lyon Springtime Fun', 'image' => '/module_d_api.php/image.png?title=Easter Egg Hunt: Lyon Springtime Fun', 'date' => '2029-04-12'],
        ['title' => 'Summer Music Festival: Lyon Outdoor Concerts', 'image' => '/module_d_api.php/image.png?title=Summer Music Festival: Lyon Outdoor Concerts', 'date' => '2029-06-21'],
        ['title' => 'Vintage Car Show: Lyon Classic Cars', 'image' => '/module_d_api.php/image.png?title=Vintage Car Show: Lyon Classic Cars', 'date' => '2029-07-01'],
        ['title' => 'Bastille Day Parade: Lyon French National Day', 'image' => '/module_d_api.php/image.png?title=Bastille Day Parade: Lyon French National Day', 'date' => '2029-07-14'],
        ['title' => 'Les Nuits de Fourvière: Lyon Outdoor Theater', 'image' => '/module_d_api.php/image.png?title=Les Nuits de Fourvière: Lyon Outdoor Theater', 'date' => '2029-07-15'],
        ['title' => 'Autumn Wine Festival: Lyon Harvest Season', 'image' => '/module_d_api.php/image.png?title=Autumn Wine Festival: Lyon Harvest Season', 'date' => '2029-09-20'],
    ];

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eventos</title>
    <link rel="stylesheet" href="./assets/style.css">
</head>
<body>
    <header>
        <h1>Eventos</h1><a href="./index.php">Voltar</a>
    </header>
    <main>
        <section class="cards">
            <?php foreach($eventos as $evento): ?>
                <div class="evento">
                    <p><?= $evento['title'] ?></p>
                    <img src="<?= $evento['image'] ?>" alt="Imagem Do Evento">
                    <p><?= $evento['date'] ?></p>
                </div>
            <?php endforeach; ?>
        </section>
    </main>
    <footer>
        <nav>
            <ul>
                <li><a href="./estacionamentos.php">Estacionamentos</a></li>
                <li><a href="./eventos.php"><strong>Eventos</strong></a></li>
                <li><a href="./clima.php">Clima</a></li>
                <li><a href="./ambiente.php">Ambiente</a></li>
            </ul>
        </nav>
    </footer>
</body>
</html>