const settings_button = document.getElementById("settings");
const settings_content = document.getElementById("settings_content");
const mode_div = document.getElementById("mode");
const theme_div = document.getElementById("theme");
const fullscreen_button = document.getElementById("tela_cheia");
const slide = document.getElementById("slide");
let settings_opened = false;
let left = true;
let automatic = false;

settings_button.onclick = () => {
    settings_content.style.display = "inherit";
    settings_opened = true;
}

let i = 1;
let m = 0;

window.addEventListener("keydown", (event) => {
    if(settings_opened == true){
        
        if(event.key == "Escape"){
            settings_content.style.display = "none";
            settings_opened = false;
        }

        if(event.key == "Enter"){
            let selected = document.querySelector(".selected");
            switch(selected.id){
                case"li1":
                    mode_div.innerHTML = "Modo atual: Manual"
                    slide.classList.remove("animated");
                    automatic = false;
                break;
                case"li2":
                    mode_div.innerHTML = "Modo atual: Automático";
                    slide.classList.add("animated");
                    automatic = true;
                break;
                case"li3":
                    mode_div.innerHTML = "Modo atual: Aleatório"
                    slide.classList.remove("animated");
                    automatic = true;
                break;
                case"li4": 
                    theme_div.innerHTML = "Tema atual: A" 
                break;
                case"li5": 
                    theme_div.innerHTML = "Tema atual: B" 
                break;
                case"li6": 
                    theme_div.innerHTML = "Tema atual: C" 
                break;
                case"li7": 
                    theme_div.innerHTML = "Tema atual: D" 
                break;
                case"li8": 
                    theme_div.innerHTML = "Tema atual: E" 
                break;
                case"li9": 
                    theme_div.innerHTML = "Tema atual: F" 
                break;
            }
        }
        
        let actual_settings = document.getElementById(`li${i}`);
        switch(event.key){
            case "ArrowDown":
                if(i++ < 12){
                    i--;
                    actual_settings.classList.remove("selected");
                    i++;
                    document.getElementById(`li${i}`).classList.add("selected");
                } else { i-- }
            break;
            case "ArrowUp":
                if(i-- > 0){
                    i++;
                    actual_settings.classList.remove("selected");
                    i--;
                    document.getElementById(`li${i}`).classList.add("selected");
                } else { i++; }
            break;
        }
    }

    if(event.key == "k" || event.key == "/"){
        settings_content.style.display = "inherit";
        settings_opened = true;
    }

    if(event.key == "ArrowLeft"){ 
        if(m - 100 > -100){
            m = m - 100;
            slide.style.marginLeft = `-${m}%`;
        } else { m = m + 100 }
    }
    if(event.key == "ArrowRight"){
        if(m + 100 < 400){
            m = m + 100;
            slide.style.marginLeft = `-${m}%`;
        } else { m = m - 100 }
    }
});

fullscreen_button.onclick = () => {
    slide.requestFullscreen();
}